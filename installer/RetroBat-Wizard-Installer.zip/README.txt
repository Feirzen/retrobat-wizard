Unzip these files into your RetroBat folder (next to RetroBat.exe),
close RetroBat, then double-click INSTALL THE WIZARD.bat.

token.txt is the shared key for the wizard's friends list. It only reaches
the friends list, nothing else.
