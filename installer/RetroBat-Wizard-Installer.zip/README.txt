Unzip these files anywhere (your Downloads folder is fine) and
double-click INSTALL THE WIZARD.bat. Close RetroBat first.

It finds RetroBat by itself (C:\RetroBat, or RetroBat at the top of any
drive). If yours is somewhere else, it asks you to pick the folder.

token.txt is the shared key for the wizard's friends list. It only reaches
the friends list, nothing else.
